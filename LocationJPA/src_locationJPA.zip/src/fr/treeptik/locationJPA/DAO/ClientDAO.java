package fr.treeptik.locationJPA.DAO;

import fr.treeptik.locationJPA.domain.Client;

public interface ClientDAO extends GenericDAO<Client, Integer>{
	
	//on met ici uniquement la signature des méthodes qui sont propres au client

}
